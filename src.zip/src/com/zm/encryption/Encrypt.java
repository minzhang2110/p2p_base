package com.zm.encryption;

/**
 * Created by Administrator on 2015/11/22.
 */
public enum Encrypt{
    NONE, AES, MHXY
}
