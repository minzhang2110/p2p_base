package com.zm.Field;

/**
 * Created by Administrator on 2015/11/22.
 */
public enum  Order {
    NET, HOST
}
