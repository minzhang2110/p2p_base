package com.zm.utils;

/**
 * Created by zhangmin on 2015/11/13.
 * BU : BYTES UTILS
 */
public class BU extends BytesUtils {
}
