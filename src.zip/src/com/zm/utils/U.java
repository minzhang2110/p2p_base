package com.zm.utils;

/**
 * Created by zhangmin on 2015/11/13.
 * U: UTILS
 */
public class U extends Utils {
}
